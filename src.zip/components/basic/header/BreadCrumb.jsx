import { MdOutlineDoubleArrow } from "react-icons/md";

const BreadCrumb = () => {
  return (
    <div>
      <MdOutlineDoubleArrow style={{ fontSize: 30 }} />
    </div>
  );
};
export default BreadCrumb;
