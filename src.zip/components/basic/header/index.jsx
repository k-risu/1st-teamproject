import Header from "./Header";

const index = () => {
  return (
    <>
      <Header />
    </>
  );
};
export default index;
